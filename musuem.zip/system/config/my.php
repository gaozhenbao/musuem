<?php
$config->installed    = true;	
$config->debug        = false;	
$config->requestType  = 'GET';	
$config->db->host     = 'localhost';	
$config->db->port     = '3306';	
$config->db->name     = 'museum';	
$config->db->user     = 'root';	
$config->db->password = '123';
$config->db->prefix   = 'eps_';	