<?php
$config->forum->newDays = 3;
$config->forum->recPerPage = 10;
