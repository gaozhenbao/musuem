<?php
/* Set the recPerPage of class. */
$config->class->recPerPage = 30;
