<?php
$lang->site->menu->search = 'Build Search Index|search|buildindex|';
