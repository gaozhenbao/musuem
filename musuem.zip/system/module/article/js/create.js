$(document).ready(function()
{
    $('#source').change();
    $('#isLink').change();
});
