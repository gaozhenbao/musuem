<?php
/* Set the recPerPage of blog. */
$config->blog->recPerPage = 10;
