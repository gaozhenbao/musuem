<?php 
$lang->admin->shortcuts = new stdclass();

$lang->admin->shortcuts->article  = 'Article';
$lang->admin->shortcuts->product  = 'Product';
$lang->admin->shortcuts->feedback = 'Feedback';
$lang->admin->shortcuts->site     = 'Site';
$lang->admin->shortcuts->logo     = 'Logo';
$lang->admin->shortcuts->company  = 'Company';
$lang->admin->shortcuts->contact  = 'Contact';

$lang->admin->adminEntry = "Warning: You're using the default admin.php, please rename it for security reason.";
