<?php 
$lang->admin->shortcuts = new stdclass();

$lang->admin->shortcuts->article  = '发布文章';
$lang->admin->shortcuts->product  = '添加产品';
$lang->admin->shortcuts->feedback = '处理反馈';
$lang->admin->shortcuts->site     = '站点设置';
$lang->admin->shortcuts->logo     = 'LOGO设置';
$lang->admin->shortcuts->company  = '学校信息';
$lang->admin->shortcuts->contact  = '联系方式';

$lang->admin->adminEntry = '警告：您现在的管理入口还是默认的admin.php，建议将admin.php改名以增强系统安全!';
