<?php 
$lang->admin->shortcuts = new stdclass();

$lang->admin->shortcuts->article  = '發佈文章';
$lang->admin->shortcuts->product  = '添加產品';
$lang->admin->shortcuts->feedback = '處理反饋';
$lang->admin->shortcuts->site     = '站點設置';
$lang->admin->shortcuts->logo     = 'LOGO設置';
$lang->admin->shortcuts->company  = '学校信息';
$lang->admin->shortcuts->contact  = '聯繫方式';

$lang->admin->adminEntry = '警告：您現在的管理入口還是預設的admin.php，建議將admin.php改名以增強系統安全!';
