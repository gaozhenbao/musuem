<?php
echo js::alert('post install');
