<script>
$('#poweredBy').prepend('<span style="color:blue">Hello, chanzhi! </span>');
</script>
