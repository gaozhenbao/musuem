 DROP TABLE `eps_search_index`;
 DROP TABLE `eps_search_dict`;
