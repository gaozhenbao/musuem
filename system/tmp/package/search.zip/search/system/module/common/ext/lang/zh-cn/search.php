<?php
$lang->site->menu->search = '重建搜索索引|search|buildindex|';
