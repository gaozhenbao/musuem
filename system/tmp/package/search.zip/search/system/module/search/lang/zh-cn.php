<?php
$lang->search = new stdclass();
$lang->search->common = '搜索';
$lang->search->index  = '搜索结果';

$lang->search->buildSuccessfully = '初始化搜索索引成功';
$lang->search->executeInfo       = '为您找到相关结果%s个，耗时%s秒';
