<?php
/**
 * The view file of product category of chanzhiEPS.
 *
 * @copyright   Copyright 2013-2013 青岛息壤网络信息有限公司 (QingDao XiRang Network Infomation Co,LTD www.xirangit.com)
 * @license     LGPL
 * @author      Tingting Dai <daitingting@xirangit.com>
 * @package     product
 * @version     $Id$
 * @link        http://www.chanzhi.org
 */
?>
<?php 
include '../../../common/view/header.html.php'; 
include '../../../common/view/treeview.html.php'; 

/* set categoryPath for topNav highlight. */
js::set('path',  $product->path);
js::set('productID', $product->id);
?>
<?php $common->printPositionBar($category, $product);?>
<div class='row'>
  <div class='col-md-9'>
    <div class='panel panel-body'>
      <div class='row'>
        <?php if(!empty($product->images)):?>
        <div class='col-md-6'>
        <?php else:?>
        <div class='col-md-12'>
        <?php endif;?>
          <div class='product-property<?php echo empty($product->images)?' product-lack-img':'';?>'>
            <h1 class='header-dividing'><?php echo $product->name;?></h1>
            <ul class='list-unstyled meta-list'>
              <?php
              $attributeHtml = '';
              if($product->promotion != 0)
              {
                  if($product->price != 0)
                  {
                      $attributeHtml .= "<li><span class='meta-name'>" . $lang->product->price . "</span>";
                      $attributeHtml .= "<span class='meta-value'><span class='text-muted text-latin'>" . $lang->RMB . "</span> <del><strong class='text-latin'>" . $product->price . "</del></strong></span></li>";
                  }
                  $attributeHtml .= "<li><span class='meta-name'>" . $lang->product->promotion . "</span>";
                  $attributeHtml .= "<span class='meta-value'><span class='text-muted text-latin'>" . $lang->RMB . "</span> <strong class='text-danger text-latin text-lg'>" . $product->promotion . "</strong></span></li>";
              }
              else if($product->price != 0)
              {
                  $attributeHtml .= "<li><span class='meta-name'>" . $lang->product->price . "</span>";
                  $attributeHtml .= "<span class='meta-value'><span class='text-muted text-latin'>" . $lang->RMB . "</span> <strong class='text-important text-latin text-lg'>" . $product->price . "</strong></span></li>";
              }
              if($product->amount)
              {
                  $attributeHtml .= "<li><span class='meta-name'>" . $lang->product->amount . "</span>";
                  $attributeHtml .= "<span class='meta-value'>" . $product->amount . " <small>" . $product->unit . "</small></span></li>";
              }
              if($product->brand)
              {
                  $attributeHtml .= "<li><span class='meta-name'>" . $lang->product->brand . "</span>";
                  $attributeHtml .= "<span class='meta-value'>" . $product->brand . " <small>" . $product->model . "</small></span></li>";
              }
              if($product->color)
              {
                $attributeHtml .= "<li><span class='meta-name'>" . $lang->product->color . "</span>";
                $attributeHtml .= "<span class='meta-value'>" . $product->color . "</span></li>";
              }
              if($product->origin)
              {
                $attributeHtml .= "<li><span class='meta-name'>" . $lang->product->origin . "</span>";
                $attributeHtml .= "<span class='meta-value'>" . $product->origin . "</span></li>";
              }
                
              if(!$attributeHtml) $attributeHtml = "<li>$product->summary</li>";
              echo $attributeHtml;
              ?>
            </ul>
            <?php if($product->mall):?>
            <hr>
            <div class='btn-buy'>
            <?php echo html::linkButton($lang->product->buyNow, $product->mall, 'btn btn-lg btn-primary');?>
            </div>
            <?php endif;?>
          </div>
        </div>
      </div>
      <div class='article-content'>
          <link rel="stylesheet" href="/css/lrtk.css" type="text/css" media="screen">
          <SCRIPT type=text/javascript src="/js/jquery.js"></SCRIPT>
<SCRIPT type=text/javascript src="/js/slide.js"></SCRIPT>

<DIV style="HEIGHT: 750px; PADDING-TOP: 20px" class="wrap picshow"><!--大图轮换区-->
<DIV id=picarea>
<DIV style="MARGIN: 0px auto; WIDTH: 800px; HEIGHT: 600px; OVERFLOW: hidden">
<DIV style="MARGIN: 0px auto; WIDTH: 800px; HEIGHT: 600px; OVERFLOW: hidden" id=bigpicarea>
<P class=bigbtnPrev><SPAN id=big_play_prev></SPAN></P>

  <?php $i=1; foreach($product->files as $photo): ?>
  <DIV id=image_xixi-<?php echo $i++; ?> class=image><IMG alt="" 
src="<?php echo $photo->fullURL;?>" width=800 height=600>
<DIV class=word>
<H3><?php echo $photo->title;?></H3></DIV></DIV>
  <?php endforeach;?>


<P class=bigbtnNext><SPAN id=big_play_next></SPAN></P></DIV></DIV>
<DIV id=smallpicarea>
<DIV id=thumbs>
<UL>
  <LI class="first btnPrev"><IMG id=play_prev src="/images/left.png"></LI>
  <?php $i=1; foreach($product->files as $photo): ?>
  <LI class=slideshowItem>
      <A id=thumb_xixi-<?php echo $i++; ?> href="#"><IMG src="<?php echo $photo->fullURL;?>" width=90 height=60></A>
  </LI>
  <?php endforeach;?>

  <LI class="last btnNext"><IMG id=play_next src="/images/right.png"></LI>
</UL></DIV></DIV></DIV>
<SCRIPT>

  <?php $strr ="";
  $i=1; foreach($product->files as $photo): 
            $arstr = "xixi-".$i++;
  if($i==2) 
          $strr ="\"$arstr\"";
      else
    $strr =$strr. "," ."\"$arstr\"";
  endforeach;   
     ?>
     var target = [<?php echo $strr;?>];
</SCRIPT>
</DIV>
      </div>
    </div>
    <div id='comments'>
      <div id='commentBox'></div>
      <?php echo html::a('', '', "name='comment'");?>
    </div>
  </div>
  <div class='col-md-3'>
    <side class='page-side'><?php $this->block->printRegion($layouts, 'product_view', 'side');?></side>
  </div>
</div>
<?php include '../../common/view/footer.html.php'; ?>
